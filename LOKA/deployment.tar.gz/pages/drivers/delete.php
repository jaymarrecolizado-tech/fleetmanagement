<?php
/**
 * LOKA - Delete Driver
 */

requireRole(ROLE_APPROVER);

$driverId = (int) get('id');
$driver = db()->fetch("SELECT * FROM drivers WHERE id = ? AND deleted_at IS NULL", [$driverId]);

if (!$driver)
    redirectWith('/?page=drivers', 'danger', 'Driver not found.');

if ($driver->status === DRIVER_ON_TRIP) {
    redirectWith('/?page=drivers', 'danger', 'Cannot delete driver who is currently on a trip.');
}

db()->softDelete('drivers', 'id = ?', [$driverId]);
auditLog('driver_deleted', 'driver', $driverId, (array) $driver);

redirectWith('/?page=drivers', 'success', 'Driver deleted successfully.');
