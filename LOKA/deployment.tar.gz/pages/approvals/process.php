<?php
/**
 * LOKA - Process Approval Action
 */

requireRole(ROLE_APPROVER);
requireCsrf();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/?page=approvals');
}

$requestId = (int) post('request_id');
$action = post('action'); // 'approve' or 'reject'
$approvalType = post('approval_type'); // 'department' or 'motorpool'
$comments = post('comments');
$vehicleId = post('vehicle_id') ?: null;
$driverId = post('driver_id') ?: null;

// Validate action
if (!in_array($action, ['approve', 'reject'])) {
    redirectWith('/?page=approvals', 'danger', 'Invalid action.');
}

// Get request
$request = db()->fetch(
    "SELECT * FROM requests WHERE id = ? AND deleted_at IS NULL",
    [$requestId]
);

if (!$request) {
    redirectWith('/?page=approvals', 'danger', 'Request not found.');
}

// Validate permissions - now checks if current user is the assigned approver
$canProcess = false;
if ($approvalType === 'motorpool' && $request->status === STATUS_PENDING_MOTORPOOL) {
    // Check if user is assigned motorpool head OR is admin OR (is motorpool role AND no specific assignment)
    if ($request->motorpool_head_id == userId() || isAdmin() || (isMotorpool() && !$request->motorpool_head_id)) {
        $canProcess = true;
    }
} elseif ($approvalType === 'department' && $request->status === STATUS_PENDING) {
    // Check if user is assigned approver OR is admin OR (is approver in same dept AND no specific assignment)
    if (
        $request->approver_id == userId() || isAdmin() ||
        (isApprover() && !$request->approver_id && $request->department_id === currentUser()->department_id)
    ) {
        $canProcess = true;
    }
}

if (!$canProcess) {
    redirectWith('/?page=approvals', 'danger', 'You are not authorized to process this request.');
}

// Rejection requires comments
if ($action === 'reject') {
    $comments = trim($comments);
    if (empty($comments)) {
        $errorMsg = 'Comments are required when rejecting a request.';
        if (isset($_POST['ajax']) && $_POST['ajax'] == '1') {
            header('Content-Type: application/json');
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $errorMsg
            ]);
            exit;
        }
        redirectWith('/?page=approvals&action=view&id=' . $requestId, 'danger', $errorMsg);
    }
}

// Motorpool approval requires vehicle and driver
if ($approvalType === 'motorpool' && $action === 'approve') {
    if (!$vehicleId || !$driverId) {
        $errorMsg = 'Vehicle and driver assignment required for approval.';
        if (isset($_POST['ajax']) && $_POST['ajax'] == '1') {
            header('Content-Type: application/json');
            http_response_code(400);
            echo json_encode([
                'success' => false,
                'message' => $errorMsg
            ]);
            exit;
        }
        redirectWith('/?page=approvals&action=view&id=' . $requestId, 'danger', $errorMsg);
    }
}

try {
    db()->beginTransaction();

    $oldStatus = $request->status;
    $newStatus = '';

    if ($action === 'approve') {
        if ($approvalType === 'department') {
            // Move to motorpool queue
            $newStatus = STATUS_PENDING_MOTORPOOL;
        } else {
            // Final approval
            $newStatus = STATUS_APPROVED;

            // Assign vehicle and driver
            db()->update('requests', [
                'vehicle_id' => $vehicleId,
                'driver_id' => $driverId
            ], 'id = ?', [$requestId]);

            // Update vehicle status
            db()->update('vehicles', ['status' => VEHICLE_IN_USE], 'id = ?', [$vehicleId]);

            // Update driver status
            db()->update('drivers', ['status' => DRIVER_ON_TRIP], 'id = ?', [$driverId]);
        }
    } else {
        // Rejected
        $newStatus = STATUS_REJECTED;
    }

    // Update request status
    db()->update('requests', [
        'status' => $newStatus,
        'updated_at' => date(DATETIME_FORMAT)
    ], 'id = ?', [$requestId]);

    // Create approval record
    db()->insert('approvals', [
        'request_id' => $requestId,
        'approver_id' => userId(),
        'approval_type' => $approvalType,
        'status' => $action === 'approve' ? 'approved' : 'rejected',
        'comments' => $comments,
        'created_at' => date(DATETIME_FORMAT)
    ]);

    // Update workflow
    $workflowData = [
        'status' => $action === 'approve' ? 'approved' : 'rejected',
        'comments' => $comments,
        'action_at' => date(DATETIME_FORMAT),
        'updated_at' => date(DATETIME_FORMAT)
    ];

    if ($approvalType === 'department') {
        $workflowData['approver_id'] = userId();
        if ($action === 'approve') {
            $workflowData['step'] = 'motorpool';
        }
    } else {
        $workflowData['motorpool_head_id'] = userId();
    }

    db()->update('approval_workflow', $workflowData, 'request_id = ?', [$requestId]);

    // Prepare notification messages based on action and approval level
    $notifyType = $action === 'approve' ? 'request_approved' : 'request_rejected';
    $notifyTitle = $action === 'approve' ? 'Request Approved' : 'Request Rejected';
    
    if ($action === 'approve') {
        if ($approvalType === 'motorpool') {
            // Final approval - notify all parties with vehicle/driver details
            $vehicle = db()->fetch("SELECT plate_number, make, model FROM vehicles WHERE id = ?", [$vehicleId]);
            $driver = db()->fetch("SELECT d.*, u.name as driver_name FROM drivers d JOIN users u ON d.user_id = u.id WHERE d.id = ?", [$driverId]);
            
            $vehicleInfo = $vehicle ? ($vehicle->plate_number . ' - ' . $vehicle->make . ' ' . $vehicle->model) : 'Vehicle assigned';
            $driverInfo = $driver ? $driver->driver_name : 'Driver assigned';
            
            // Notify requester
            notify(
                $request->user_id,
                $notifyType,
                $notifyTitle,
                'Your request has been fully approved! Vehicle: ' . $vehicleInfo . ', Driver: ' . $driverInfo . '.',
                '/?page=requests&action=view&id=' . $requestId
            );
            
            // Notify passengers
            notifyPassengers(
                $requestId,
                $notifyType,
                $notifyTitle,
                'A trip you are part of has been fully approved. Vehicle: ' . $vehicleInfo . ', Driver: ' . $driverInfo . '.',
                '/?page=requests&action=view&id=' . $requestId
            );
            
            // Notify assigned driver
            if ($driverId) {
                notifyDriver(
                    $driverId,
                    'driver_assigned',
                    'You Have Been Assigned as Driver',
                    'You have been assigned as the driver for a trip to ' . $request->destination . ' on ' . date('M j, Y g:i A', strtotime($request->start_datetime)) . '. Vehicle: ' . $vehicleInfo . '.',
                    '/?page=requests&action=view&id=' . $requestId
                );
            }
        } else {
            // Department approval - notify all parties
            $requesterMessage = 'Your request has been approved by department and forwarded to motorpool for vehicle assignment.';
            $passengerMessage = 'A trip you are part of has been approved by department and is awaiting motorpool assignment.';
            $driverMessage = 'A trip you were requested to drive has been approved by department and is awaiting motorpool approval.';
            
            notify($request->user_id, $notifyType, $notifyTitle, $requesterMessage, '/?page=requests&action=view&id=' . $requestId);
            notifyPassengers($requestId, $notifyType, $notifyTitle, $passengerMessage, '/?page=requests&action=view&id=' . $requestId);
            
            // Notify requested driver if exists
            if ($request->requested_driver_id) {
                notifyDriver($request->requested_driver_id, 'driver_status_update', $notifyTitle, $driverMessage, '/?page=requests&action=view&id=' . $requestId);
            }
        }
    } else {
        // Rejection - notify all parties
        $rejectionMessage = 'Your request has been rejected. ' . ($comments ? 'Reason: ' . $comments : '');
        $passengerRejectionMessage = 'A trip you were added to has been rejected. ' . ($comments ? 'Reason: ' . $comments : '');
        $driverRejectionMessage = 'A trip you were requested to drive has been rejected. ' . ($comments ? 'Reason: ' . $comments : '');
        
        notify($request->user_id, $notifyType, $notifyTitle, $rejectionMessage, '/?page=requests&action=view&id=' . $requestId);
        notifyPassengers($requestId, $notifyType, $notifyTitle, $passengerRejectionMessage, '/?page=requests&action=view&id=' . $requestId);
        
        // Notify requested driver if exists
        if ($request->requested_driver_id) {
            notifyDriver($request->requested_driver_id, 'trip_cancelled_driver', $notifyTitle, $driverRejectionMessage, '/?page=requests&action=view&id=' . $requestId);
        }
    }

    // If department approved, notify the assigned motorpool head
    if ($approvalType === 'department' && $action === 'approve') {
        if ($request->motorpool_head_id) {
            // Notify specific assigned motorpool head
            notify(
                $request->motorpool_head_id,
                'request_pending_motorpool',
                'New Request Awaiting Your Approval',
                'A vehicle request has been approved by department and needs your approval and vehicle assignment.',
                '/?page=approvals&action=view&id=' . $requestId
            );
        } else {
            // Fallback: notify all motorpool heads if none specifically assigned
            $motorpoolUsers = db()->fetchAll(
                "SELECT id FROM users WHERE role IN ('motorpool', 'admin') AND status = 'active'"
            );
            foreach ($motorpoolUsers as $user) {
                notify(
                    $user->id,
                    'request_pending_motorpool',
                    'New Request Awaiting Motorpool Approval',
                    'A request from ' . currentUser()->name . '\'s department needs vehicle assignment.',
                    '/?page=approvals&action=view&id=' . $requestId
                );
            }
        }
    }

    // Audit log
    auditLog(
        $action === 'approve' ? 'request_approved' : 'request_rejected',
        'request',
        $requestId,
        ['status' => $oldStatus],
        ['status' => $newStatus, 'approval_type' => $approvalType, 'comments' => $comments, 'override_conflict' => post('override_conflict') ? true : false]
    );

    db()->commit();

    $message = $action === 'approve' ? 'Request approved successfully.' : 'Request rejected.';
    
    // If AJAX request, return JSON
    if (isset($_POST['ajax']) && $_POST['ajax'] == '1') {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => $message
        ]);
        exit;
    }
    
    redirectWith('/?page=approvals', 'success', $message);

} catch (Exception $e) {
    db()->rollback();
    error_log("Approval processing error: " . $e->getMessage());
    
    // If AJAX request, return JSON error
    if (isset($_POST['ajax']) && $_POST['ajax'] == '1') {
        header('Content-Type: application/json');
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Failed to process approval. Please try again.'
        ]);
        exit;
    }
    
    redirectWith('/?page=approvals&action=view&id=' . $requestId, 'danger', 'Failed to process approval. Please try again.');
}
