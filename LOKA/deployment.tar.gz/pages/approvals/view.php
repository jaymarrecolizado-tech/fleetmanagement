<?php
/**
 * LOKA - Approval Review Page
 */

requireRole(ROLE_APPROVER);

$requestId = (int) get('id');

// Get request with full details
$request = db()->fetch(
    "SELECT r.*, 
            u.name as requester_name, u.email as requester_email, u.phone as requester_phone,
            d.name as department_name
     FROM requests r
     JOIN users u ON r.user_id = u.id
     JOIN departments d ON r.department_id = d.id
     WHERE r.id = ? AND r.deleted_at IS NULL",
    [$requestId]
);

if (!$request) {
    redirectWith('/?page=approvals', 'danger', 'Request not found.');
}

// Check if user can approve this request
$canApprove = false;
$approvalType = '';

if ($request->status === STATUS_PENDING_MOTORPOOL && (isMotorpool() || isAdmin())) {
    $canApprove = true;
    $approvalType = 'motorpool';
} elseif ($request->status === STATUS_PENDING && ($request->department_id === currentUser()->department_id || isAdmin())) {
    $canApprove = true;
    $approvalType = 'department';
}

// Get available vehicles (for motorpool)
$availableVehicles = [];
$availableDrivers = [];

if ($approvalType === 'motorpool') {
    $availableDrivers = db()->fetchAll(
        "SELECT d.*, u.name as driver_name, u.phone as driver_phone
         FROM drivers d
         JOIN users u ON d.user_id = u.id
         WHERE d.deleted_at IS NULL
         AND u.status = 'active' AND u.deleted_at IS NULL
         ORDER BY u.name"
    );

    $availableVehicles = db()->fetchAll(
        "SELECT v.*, vt.name as type_name, vt.passenger_capacity
         FROM vehicles v
         JOIN vehicle_types vt ON v.vehicle_type_id = vt.id
         WHERE v.deleted_at IS NULL
         ORDER BY vt.name, v.plate_number"
    );
}

// Get the requested driver name if any
$requestedDriver = null;
if ($request->requested_driver_id) {
    $requestedDriver = db()->fetch(
        "SELECT u.name FROM drivers d JOIN users u ON d.user_id = u.id WHERE d.id = ?",
        [$request->requested_driver_id]
    );
}

// Get approval history
$approvals = db()->fetchAll(
    "SELECT a.*, u.name as approver_name
     FROM approvals a
     JOIN users u ON a.approver_id = u.id
     WHERE a.request_id = ?
     ORDER BY a.created_at ASC",
    [$requestId]
);

$pageTitle = 'Review Request #' . $requestId;

require_once INCLUDES_PATH . '/header.php';
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">Review Request #<?= $requestId ?></h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?= APP_URL ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?= APP_URL ?>/?page=approvals">Approvals</a></li>
                    <li class="breadcrumb-item active">Review</li>
                </ol>
            </nav>
        </div>
        <div>
            <?= requestStatusBadge($request->status) ?>
        </div>
    </div>

    <div class="row g-4">
        <!-- Request Details -->
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-file-earmark-text me-2"></i>Request Details</h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="text-muted small">Requester</label>
                            <div class="fw-bold"><?= e($request->requester_name) ?></div>
                            <small class="text-muted"><?= e($request->requester_email) ?></small>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Department</label>
                            <div class="fw-bold"><?= e($request->department_name) ?></div>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">Start Date/Time</label>
                            <div class="fw-medium"><?= formatDateTime($request->start_datetime) ?></div>
                        </div>
                        <div class="col-md-6">
                            <label class="text-muted small">End Date/Time</label>
                            <div class="fw-medium"><?= formatDateTime($request->end_datetime) ?></div>
                        </div>
                        <div class="col-12">
                            <label class="text-muted small">Purpose</label>
                            <div class="fw-medium"><?= nl2br(e($request->purpose)) ?></div>
                        </div>
                        <div class="col-md-8">
                            <label class="text-muted small">Destination</label>
                            <div class="fw-medium"><?= e($request->destination) ?></div>
                        </div>
                        <div class="col-md-4">
                            <label class="text-muted small">Passenger Count</label>
                            <div class="fw-medium"><?= $request->passenger_count ?></div>
                        </div>
                        <!-- Passengers List -->
                        <?php
                        $passengers = db()->fetchAll(
                            "SELECT rp.*, u.name as user_name, u.email as user_email, d.name as department_name
                             FROM request_passengers rp
                             LEFT JOIN users u ON rp.user_id = u.id
                             LEFT JOIN departments d ON u.department_id = d.id
                             WHERE rp.request_id = ?
                             ORDER BY 
                                 CASE WHEN rp.user_id IS NOT NULL THEN 0 ELSE 1 END,
                                 u.name ASC, rp.guest_name ASC",
                            [$requestId]
                        );
                        ?>
                        <?php if (!empty($passengers)): ?>
                            <div class="col-12 mt-3">
                                <label class="text-muted small mb-2 d-block">
                                    <i class="bi bi-people-fill me-1"></i>Passengers List
                                </label>
                                <div class="border rounded p-3 bg-light">
                                    <div class="row g-2">
                                        <!-- Requester (always first) -->
                                        <div class="col-12 col-md-6 mb-2">
                                            <div class="d-flex align-items-center p-2 bg-white rounded border">
                                                <div class="bg-primary bg-opacity-10 p-2 rounded-circle me-2">
                                                    <i class="bi bi-person-fill text-primary"></i>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <div class="fw-bold small"><?= e($request->requester_name) ?></div>
                                                    <div class="x-small text-primary fw-medium">Requester</div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Other Passengers -->
                                        <?php foreach ($passengers as $passenger): ?>
                                            <div class="col-12 col-md-6 mb-2">
                                                <div class="d-flex align-items-center p-2 bg-white rounded border">
                                                    <?php if ($passenger->user_id): ?>
                                                        <!-- System User -->
                                                        <div class="bg-secondary bg-opacity-10 p-2 rounded-circle me-2">
                                                            <i class="bi bi-person text-secondary"></i>
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <div class="fw-bold small"><?= e($passenger->user_name) ?></div>
                                                            <div class="x-small text-muted">
                                                                <?= e($passenger->department_name ?: 'No Department') ?>
                                                            </div>
                                                            <?php if ($passenger->user_email): ?>
                                                                <div class="x-small text-muted">
                                                                    <i class="bi bi-envelope me-1"></i><?= e($passenger->user_email) ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php else: ?>
                                                        <!-- Guest -->
                                                        <div class="bg-success bg-opacity-10 p-2 rounded-circle me-2">
                                                            <i class="bi bi-person-plus text-success"></i>
                                                        </div>
                                                        <div class="flex-grow-1">
                                                            <div class="fw-bold small"><?= e($passenger->guest_name) ?></div>
                                                            <div class="x-small text-success fw-medium">External Guest</div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if ($requestedDriver): ?>
                            <div class="col-12 mt-2">
                                <label class="text-muted small">Requested Driver</label>
                                <div class="d-flex align-items-center">
                                    <span class="fw-bold text-primary"><i
                                            class="bi bi-person-badge me-1"></i><?= e($requestedDriver->name) ?></span>
                                    <div id="requestedDriverConflict" class="ms-3 small text-danger d-none">
                                        <i class="bi bi-exclamation-circle me-1"></i>Conflict detected!
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if ($request->notes): ?>
                            <div class="col-12">
                                <label class="text-muted small">Additional Notes</label>
                                <div><?= nl2br(e($request->notes)) ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Approval History -->
            <?php if (!empty($approvals)): ?>
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Approval History</h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($approvals as $approval): ?>
                            <div class="d-flex mb-3">
                                <div class="me-3">
                                    <span
                                        class="badge bg-<?= $approval->status === 'approved' ? 'success' : 'danger' ?> rounded-circle p-2">
                                        <i class="bi bi-<?= $approval->status === 'approved' ? 'check' : 'x' ?>-lg"></i>
                                    </span>
                                </div>
                                <div>
                                    <div class="fw-medium">
                                        <?= e($approval->approver_name) ?>
                                        <span class="text-<?= $approval->status === 'approved' ? 'success' : 'danger' ?>">
                                            <?= ucfirst($approval->status) ?>
                                        </span>
                                        (<?= ucfirst($approval->approval_type) ?>)
                                    </div>
                                    <small class="text-muted"><?= formatDateTime($approval->created_at) ?></small>
                                    <?php if ($approval->comments): ?>
                                        <div class="mt-1 fst-italic">"<?= e($approval->comments) ?>"</div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Approval Action Form -->
            <?php if ($canApprove): ?>
                <div class="card border-primary">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="bi bi-check-circle me-2"></i>Take Action</h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" id="approvalForm" action="<?= APP_URL ?>/?page=approvals&action=process">
                            <?= csrfField() ?>
                            <input type="hidden" name="request_id" value="<?= $requestId ?>">
                            <input type="hidden" name="approval_type" value="<?= $approvalType ?>">

                            <?php if ($approvalType === 'motorpool'): ?>
                                <!-- Vehicle/Driver Assignment (Only for Approval) -->
                                <div id="assignmentSection">
                                    <!-- Vehicle Selection -->
                                    <div class="mb-3">
                                        <label for="vehicle_id" class="form-label">Assign Vehicle <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" id="vehicle_id" name="vehicle_id">
                                            <option value="">Select a vehicle...</option>
                                            <?php foreach ($availableVehicles as $vehicle): ?>
                                                <option value="<?= $vehicle->id ?>">
                                                    <?= e($vehicle->plate_number) ?> - <?= e($vehicle->make . ' ' . $vehicle->model) ?>
                                                    (<?= e($vehicle->type_name) ?>, <?= $vehicle->passenger_capacity ?> seats)
                                                    <?= $vehicle->status !== 'available' ? '[' . strtoupper($vehicle->status) . ']' : '' ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div id="vehicleConflictAlert" class="alert alert-warning mt-2 small py-2 d-none">
                                            <i class="bi bi-exclamation-triangle me-1"></i>
                                            <span class="message"></span>
                                        </div>
                                        <?php if (empty($availableVehicles)): ?>
                                            <small class="text-danger">No vehicles available</small>
                                        <?php endif; ?>
                                    </div>

                                    <!-- Driver Selection -->
                                    <div class="mb-3">
                                        <label for="driver_id" class="form-label">Assign Driver <span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" id="driver_id" name="driver_id">
                                            <option value="">Select a driver...</option>
                                            <?php foreach ($availableDrivers as $driver): ?>
                                                <option value="<?= $driver->id ?>">
                                                    <?= e($driver->driver_name) ?> - <?= e($driver->license_number) ?>
                                                    (<?= $driver->years_experience ?> yrs exp)
                                                    <?= $driver->status !== 'available' ? '[' . strtoupper($driver->status) . ']' : '' ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div id="driverConflictAlert" class="alert alert-warning mt-3 small py-2 d-none">
                                            <i class="bi bi-exclamation-triangle me-1"></i>
                                            <span class="message"></span>
                                        </div>
                                    </div>

                                    <div id="overrideConfirm" class="form-check mb-3 d-none">
                                        <input class="form-check-input border-danger" type="checkbox" id="confirmOverride"
                                            name="override_conflict" value="1">
                                        <label class="form-check-label text-danger fw-bold" for="confirmOverride">
                                            I confirm this assignment despite schedule conflicts.
                                        </label>
                                    </div>
                                    <?php if (empty($availableDrivers)): ?>
                                        <small class="text-danger">No drivers available</small>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                    <!-- Comments -->
                    <div class="mb-4">
                        <label for="comments" class="form-label">
                            Comments 
                            <span class="text-danger" id="commentsRequired">*</span>
                            <span class="text-muted small" id="commentsOptional">(Optional)</span>
                        </label>
                        <textarea class="form-control" id="comments" name="comments" rows="3"
                            placeholder="Enter your comments or remarks..."></textarea>
                        <div class="invalid-feedback">Comments are required when rejecting a request.</div>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex gap-2">
                        <button type="submit" name="action" value="approve" id="approveBtn" class="btn btn-success">
                            <span class="btn-text">
                                <i class="bi bi-check-lg me-1"></i>Approve
                            </span>
                            <span class="btn-loading d-none">
                                <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                                Processing...
                            </span>
                        </button>
                        <button type="submit" name="action" value="reject" id="rejectBtn" class="btn btn-danger">
                            <span class="btn-text">
                                <i class="bi bi-x-lg me-1"></i>Reject
                            </span>
                            <span class="btn-loading d-none">
                                <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                                Processing...
                            </span>
                        </button>
                        <a href="<?= APP_URL ?>/?page=approvals" class="btn btn-outline-secondary">Cancel</a>
                    </div>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <?php if ($request->status === STATUS_APPROVED): ?>
                    This request has already been fully approved.
                <?php elseif ($request->status === STATUS_REJECTED): ?>
                    This request has been rejected.
                <?php elseif ($request->status === STATUS_CANCELLED): ?>
                    This request was cancelled by the requester.
                <?php else: ?>
                    You cannot take action on this request at this time.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0"><i class="bi bi-info-circle me-2"></i>Quick Info</h6>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <small class="text-muted">Request ID</small>
                    <div class="fw-bold">#<?= $requestId ?></div>
                </div>
                <div class="mb-3">
                    <small class="text-muted">Submitted</small>
                    <div><?= formatDateTime($request->created_at) ?></div>
                </div>
                <div class="mb-3">
                    <small class="text-muted">Duration</small>
                    <div>
                        <?php
                        $start = new DateTime($request->start_datetime);
                        $end = new DateTime($request->end_datetime);
                        $diff = $start->diff($end);
                        if ($diff->days > 0) {
                            echo $diff->days . ' day(s) ' . $diff->h . ' hour(s)';
                        } else {
                            echo $diff->h . ' hour(s) ' . $diff->i . ' min(s)';
                        }
                        ?>
                    </div>
                </div>
                <div>
                    <small class="text-muted">Contact</small>
                    <div><?= e($request->requester_phone ?: 'N/A') ?></div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const vehicleSelect = document.getElementById('vehicle_id');
        const driverSelect = document.getElementById('driver_id');
        const vAlert = document.getElementById('vehicleConflictAlert');
        const dAlert = document.getElementById('driverConflictAlert');
        const overrideBox = document.getElementById('overrideConfirm');
        const approveBtn = document.getElementById('approveBtn');
        const rejectBtn = document.getElementById('rejectBtn');
        const requestedConflict = document.getElementById('requestedDriverConflict');
        const approvalForm = document.getElementById('approvalForm');

        const start = '<?= $request->start_datetime ?>';
        const end = '<?= $request->end_datetime ?>';
        const requestId = '<?= $request->id ?>';

        function check(type, id, alertEl) {
            if (!id) {
                alertEl.classList.add('d-none');
                updateUI();
                return;
            }

            fetch(`<?= APP_URL ?>/?page=api&action=check_conflict&type=${type}&id=${id}&start=${start}&end=${end}&exclude_id=${requestId}`)
                .then(res => res.json())
                .then(data => {
                    if (data.conflict) {
                        alertEl.querySelector('.message').textContent = data.message;
                        alertEl.classList.remove('d-none');
                    } else {
                        alertEl.classList.add('d-none');
                    }
                    updateUI();
                });
        }

        function updateUI() {
            const hasConflict = !vAlert.classList.contains('d-none') || !dAlert.classList.contains('d-none');
            if (hasConflict) {
                overrideBox.classList.remove('d-none');
                if (approveBtn) {
                    approveBtn.disabled = !document.getElementById('confirmOverride').checked;
                }
            } else {
                overrideBox.classList.add('d-none');
                if (approveBtn) {
                    approveBtn.disabled = false;
                }
            }
        }

        if (vehicleSelect) vehicleSelect.addEventListener('change', () => check('vehicle', vehicleSelect.value, vAlert));
        if (driverSelect) driverSelect.addEventListener('change', () => check('driver', driverSelect.value, dAlert));
        if (overrideBox) document.getElementById('confirmOverride').addEventListener('change', updateUI);

        // Initial check for requested driver (Approver view info)
        <?php if ($request->requested_driver_id): ?>
            fetch(`<?= APP_URL ?>/?page=api&action=check_conflict&type=driver&id=<?= $request->requested_driver_id ?>&start=${start}&end=${end}&exclude_id=${requestId}`)
                .then(res => res.json())
                .then(data => {
                    if (data.conflict) requestedConflict.classList.remove('d-none');
                });
        <?php endif; ?>
        
        // Set initial state - show assignment fields by default (for approval)
        toggleAssignmentFields('approve');

        // Toggle assignment fields based on action
        function toggleAssignmentFields(action) {
            const assignmentSection = document.getElementById('assignmentSection');
            const commentsField = document.getElementById('comments');
            const commentsRequired = document.getElementById('commentsRequired');
            const commentsOptional = document.getElementById('commentsOptional');
            const vehicleSelect = document.getElementById('vehicle_id');
            const driverSelect = document.getElementById('driver_id');
            const approvalType = '<?= $approvalType ?>';
            
            if (action === 'reject') {
                // Hide assignment section for rejection (only if it exists)
                if (assignmentSection) {
                    assignmentSection.style.display = 'none';
                }
                // Make comments required for rejection
                if (commentsField) {
                    commentsField.setAttribute('required', 'required');
                    commentsField.placeholder = 'Please provide a reason for rejection (required)...';
                    commentsField.classList.remove('is-invalid');
                }
                if (commentsRequired) commentsRequired.style.display = 'inline';
                if (commentsOptional) commentsOptional.style.display = 'none';
                // Remove required from vehicle/driver (if they exist)
                if (vehicleSelect) {
                    vehicleSelect.removeAttribute('required');
                    vehicleSelect.classList.remove('is-invalid');
                }
                if (driverSelect) {
                    driverSelect.removeAttribute('required');
                    driverSelect.classList.remove('is-invalid');
                }
            } else {
                // Show assignment section for approval (only if it exists - motorpool only)
                if (assignmentSection) {
                    assignmentSection.style.display = 'block';
                }
                // Make comments optional for approval
                if (commentsField) {
                    commentsField.removeAttribute('required');
                    commentsField.placeholder = 'Optional comments...';
                    commentsField.classList.remove('is-invalid');
                }
                if (commentsRequired) commentsRequired.style.display = 'none';
                if (commentsOptional) commentsOptional.style.display = 'inline';
                // Add required to vehicle/driver for motorpool approval only
                if (approvalType === 'motorpool') {
                    if (vehicleSelect) {
                        vehicleSelect.setAttribute('required', 'required');
                    }
                    if (driverSelect) {
                        driverSelect.setAttribute('required', 'required');
                    }
                }
            }
        }
        
        // Track which button was clicked
        let clickedAction = null;
        
        // Handle button clicks to toggle fields and track action
        if (approveBtn) {
            approveBtn.addEventListener('click', function(e) {
                clickedAction = 'approve';
                toggleAssignmentFields('approve');
            });
        }
        
        if (rejectBtn) {
            rejectBtn.addEventListener('click', function(e) {
                clickedAction = 'reject';
                toggleAssignmentFields('reject');
            });
        }
        
        // AJAX form submission
        if (approvalForm) {
            approvalForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const formData = new FormData(this);
                
                // Determine which action was triggered
                let action = clickedAction;
                
                // If no button was explicitly clicked (e.g., Enter key), check the submitter
                if (!action && e.submitter) {
                    action = e.submitter.value || 'approve';
                }
                
                // If still no action, try to get from form data (but handle RadioNodeList)
                if (!action) {
                    const actionValue = formData.get('action');
                    
                    // Handle RadioNodeList or NodeList (when multiple elements have same name)
                    if (actionValue && typeof actionValue === 'object') {
                        if (actionValue.length !== undefined) {
                            // It's a NodeList/RadioNodeList
                            action = actionValue[0]?.value || String(actionValue[0] || 'approve');
                        } else if (actionValue.value !== undefined) {
                            // It's a single element
                            action = String(actionValue.value || 'approve');
                        } else {
                            action = 'approve'; // Default fallback
                        }
                    } else {
                        // It's already a string or null
                        action = String(actionValue || 'approve');
                    }
                }
                
                // Ensure action is always a string
                action = String(action);
                
                // Explicitly set the action value to ensure it's a string
                formData.set('action', action);
                
                const submitBtn = action === 'approve' ? approveBtn : rejectBtn;
                const btnText = submitBtn.querySelector('.btn-text');
                const btnLoading = submitBtn.querySelector('.btn-loading');
                const comments = formData.get('comments')?.trim() || '';
                
                // Validate comments for rejection
                if (action === 'reject' && !comments) {
                    showToast('Please provide a reason for rejection.', 'warning');
                    document.getElementById('comments').classList.add('is-invalid');
                    document.getElementById('comments').focus();
                    return;
                }
                
                // Validate vehicle/driver for motorpool approval
                const approvalType = '<?= $approvalType ?>';
                if (action === 'approve' && approvalType === 'motorpool') {
                    const vehicleId = formData.get('vehicle_id');
                    const driverId = formData.get('driver_id');
                    const vehicleSelect = document.getElementById('vehicle_id');
                    const driverSelect = document.getElementById('driver_id');
                    
                    if (!vehicleId || !driverId) {
                        showToast('Please select both a vehicle and driver for approval.', 'warning');
                        if (!vehicleId && vehicleSelect) vehicleSelect.classList.add('is-invalid');
                        if (!driverId && driverSelect) driverSelect.classList.add('is-invalid');
                        return;
                    }
                }
                
                // Clear validation classes
                document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
                
                // Disable buttons and show loading
                approveBtn.disabled = true;
                rejectBtn.disabled = true;
                btnText.classList.add('d-none');
                btnLoading.classList.remove('d-none');
                
                // Add AJAX header
                formData.append('ajax', '1');
                
                fetch(this.action, {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    const contentType = response.headers.get('content-type') || '';
                    if (contentType.includes('application/json')) {
                        return response.json();
                    }
                    // If not JSON, it's likely a redirect - use the safe redirect URL
                    return response.text().then(() => {
                        // Always use the safe redirect URL to avoid [object RadioNodeList] issues
                        window.location.href = '<?= APP_URL ?>/?page=approvals';
                    });
                })
                .then(data => {
                    // Reset clicked action
                    clickedAction = null;
                    
                    if (data && typeof data === 'object') {
                        if (data.success) {
                            showToast(data.message || (action === 'approve' ? 'Request approved successfully!' : 'Request rejected.'), 'success');
                            setTimeout(() => {
                                window.location.href = '<?= APP_URL ?>/?page=approvals';
                            }, 1500);
                        } else {
                            showToast(data.message || 'An error occurred. Please try again.', 'danger');
                            approveBtn.disabled = false;
                            rejectBtn.disabled = false;
                            btnText.classList.remove('d-none');
                            btnLoading.classList.add('d-none');
                        }
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    clickedAction = null; // Reset on error too
                    showToast('An error occurred. Please try again.', 'danger');
                    approveBtn.disabled = false;
                    rejectBtn.disabled = false;
                    btnText.classList.remove('d-none');
                    btnLoading.classList.add('d-none');
                });
            });
        }
    });
</script>