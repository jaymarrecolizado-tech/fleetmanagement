<?php
/**
 * LOKA - Approvals Queue Page
 */

requireRole(ROLE_APPROVER);

$pageTitle = 'Approval Queue';
$tab = get('tab', 'pending');

// Determine which requests to show based on role
// Now requests have specific approver_id and motorpool_head_id assigned by requester
if (isAdmin()) {
    // Admin sees ALL pending requests (both levels) - either assigned to them OR unassigned
    $pendingRequests = db()->fetchAll(
        "SELECT r.*, u.name as requester_name, d.name as department_name,
                appr.name as assigned_approver_name, mph.name as assigned_motorpool_name
         FROM requests r
         JOIN users u ON r.user_id = u.id
         JOIN departments d ON r.department_id = d.id
         LEFT JOIN users appr ON r.approver_id = appr.id
         LEFT JOIN users mph ON r.motorpool_head_id = mph.id
         WHERE r.status IN ('pending', 'pending_motorpool') AND r.deleted_at IS NULL
         ORDER BY r.status ASC, r.created_at ASC"
    );
    $queueType = 'All';
} elseif (isMotorpool()) {
    // Motorpool sees requests where they are assigned as motorpool head
    $pendingRequests = db()->fetchAll(
        "SELECT r.*, u.name as requester_name, d.name as department_name,
                appr.name as assigned_approver_name
         FROM requests r
         JOIN users u ON r.user_id = u.id
         JOIN departments d ON r.department_id = d.id
         LEFT JOIN users appr ON r.approver_id = appr.id
         WHERE r.status = 'pending_motorpool' 
         AND (r.motorpool_head_id = ? OR r.motorpool_head_id IS NULL)
         AND r.deleted_at IS NULL
         ORDER BY r.created_at ASC",
        [userId()]
    );
    $queueType = 'Motorpool';
} else {
    // Approvers see requests where they are assigned as approver
    $pendingRequests = db()->fetchAll(
        "SELECT r.*, u.name as requester_name, d.name as department_name,
                mph.name as assigned_motorpool_name
         FROM requests r
         JOIN users u ON r.user_id = u.id
         JOIN departments d ON r.department_id = d.id
         LEFT JOIN users mph ON r.motorpool_head_id = mph.id
         WHERE r.status = 'pending' 
         AND (r.approver_id = ? OR (r.approver_id IS NULL AND r.department_id = ?))
         AND r.deleted_at IS NULL
         ORDER BY r.created_at ASC",
        [userId(), currentUser()->department_id]
    );
    $queueType = 'Department';
}

// Get processed requests (approved/rejected by me)
$processedRequests = db()->fetchAll(
    "SELECT r.*, u.name as requester_name, d.name as department_name,
            a.status as my_action, a.created_at as action_date
     FROM approvals a
     JOIN requests r ON a.request_id = r.id
     JOIN users u ON r.user_id = u.id
     JOIN departments d ON r.department_id = d.id
     WHERE a.approver_id = ? AND r.deleted_at IS NULL
     ORDER BY a.created_at DESC
     LIMIT 50",
    [userId()]
);

require_once INCLUDES_PATH . '/header.php';
?>

<div class="container-fluid py-4">
    <!-- Page Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1"><?= $queueType ?> Approval Queue</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?= APP_URL ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Approvals</li>
                </ol>
            </nav>
        </div>
    </div>
    
    <!-- Tabs -->
    <ul class="nav nav-tabs mb-4">
        <li class="nav-item">
            <a class="nav-link <?= $tab === 'pending' ? 'active' : '' ?>" href="<?= APP_URL ?>/?page=approvals&tab=pending">
                <i class="bi bi-hourglass-split me-1"></i>Pending
                <?php if (count($pendingRequests) > 0): ?>
                <span class="badge bg-warning ms-1"><?= count($pendingRequests) ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?= $tab === 'processed' ? 'active' : '' ?>" href="<?= APP_URL ?>/?page=approvals&tab=processed">
                <i class="bi bi-check-circle me-1"></i>Processed
            </a>
        </li>
    </ul>
    
    <?php if ($tab === 'pending'): ?>
    <!-- Pending Approvals -->
    <div class="card table-card">
        <div class="card-body">
            <?php if (empty($pendingRequests)): ?>
            <div class="empty-state">
                <i class="bi bi-inbox"></i>
                <h5>No pending approvals</h5>
                <p class="text-muted">All caught up! No requests awaiting your approval.</p>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Requester</th>
                            <th>Department</th>
                            <th>Purpose</th>
                            <th>Date/Time</th>
                            <th>Approval Level</th>
                            <th>Submitted</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingRequests as $request): ?>
                        <tr>
                            <td><strong>#<?= $request->id ?></strong></td>
                            <td><?= e($request->requester_name) ?></td>
                            <td><span class="badge bg-light text-dark"><?= e($request->department_name) ?></span></td>
                            <td><?= truncate($request->purpose, 30) ?></td>
                            <td>
                                <div><?= formatDateTime($request->start_datetime) ?></div>
                                <small class="text-muted">to <?= formatDateTime($request->end_datetime) ?></small>
                            </td>
                            <td>
                                <?php if ($request->status === 'pending'): ?>
                                <span class="badge bg-info">Department</span>
                                <?php else: ?>
                                <span class="badge bg-primary">Motorpool</span>
                                <?php endif; ?>
                            </td>
                            <td><?= formatDateTime($request->created_at) ?></td>
                            <td>
                                <a href="<?= APP_URL ?>/?page=approvals&action=view&id=<?= $request->id ?>" 
                                   class="btn btn-sm btn-primary">
                                    <i class="bi bi-eye me-1"></i>Review
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php else: ?>
    <!-- Processed Approvals -->
    <div class="card table-card">
        <div class="card-body">
            <?php if (empty($processedRequests)): ?>
            <div class="empty-state">
                <i class="bi bi-clipboard-check"></i>
                <h5>No processed requests</h5>
                <p class="text-muted">You haven't processed any requests yet.</p>
            </div>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Requester</th>
                            <th>Purpose</th>
                            <th>Your Action</th>
                            <th>Action Date</th>
                            <th>Current Status</th>
                            <th>View</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($processedRequests as $request): ?>
                        <tr>
                            <td><strong>#<?= $request->id ?></strong></td>
                            <td><?= e($request->requester_name) ?></td>
                            <td><?= truncate($request->purpose, 30) ?></td>
                            <td>
                                <span class="badge bg-<?= $request->my_action === 'approved' ? 'success' : 'danger' ?>">
                                    <?= ucfirst($request->my_action) ?>
                                </span>
                            </td>
                            <td><?= formatDateTime($request->action_date) ?></td>
                            <td><?= requestStatusBadge($request->status) ?></td>
                            <td>
                                <a href="<?= APP_URL ?>/?page=requests&action=view&id=<?= $request->id ?>" 
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-eye"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once INCLUDES_PATH . '/footer.php'; ?>
