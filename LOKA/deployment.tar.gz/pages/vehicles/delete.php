<?php
/**
 * LOKA - Delete Vehicle
 */

requireRole(ROLE_APPROVER);

$vehicleId = (int) get('id');
$vehicle = db()->fetch("SELECT * FROM vehicles WHERE id = ? AND deleted_at IS NULL", [$vehicleId]);

if (!$vehicle)
    redirectWith('/?page=vehicles', 'danger', 'Vehicle not found.');

// Check if vehicle is in use
if ($vehicle->status === VEHICLE_IN_USE) {
    redirectWith('/?page=vehicles', 'danger', 'Cannot delete vehicle that is currently in use.');
}

// Soft delete
db()->softDelete('vehicles', 'id = ?', [$vehicleId]);
auditLog('vehicle_deleted', 'vehicle', $vehicleId, (array) $vehicle);

redirectWith('/?page=vehicles', 'success', 'Vehicle deleted successfully.');
