<?php
/**
 * LOKA - Cancel Request
 */

$requestId = (int) get('id');

// Get request
$request = db()->fetch(
    "SELECT * FROM requests WHERE id = ? AND deleted_at IS NULL",
    [$requestId]
);

if (!$request) {
    redirectWith('/?page=requests', 'danger', 'Request not found.');
}

// Check ownership
if ($request->user_id !== userId() && !isAdmin()) {
    redirectWith('/?page=requests', 'danger', 'You can only cancel your own requests.');
}

// Check if can be cancelled
$cancellableStatuses = [STATUS_PENDING, STATUS_PENDING_MOTORPOOL, STATUS_DRAFT];
if (!in_array($request->status, $cancellableStatuses)) {
    redirectWith('/?page=requests', 'danger', 'This request cannot be cancelled in its current state.');
}

// Perform cancellation
$oldStatus = $request->status;

db()->update('requests', [
    'status' => STATUS_CANCELLED,
    'cancelled_at' => date(DATETIME_FORMAT),
    'updated_at' => date(DATETIME_FORMAT)
], 'id = ?', [$requestId]);

// Update workflow
db()->update('approval_workflow', [
    'status' => 'rejected',
    'comments' => 'Cancelled by requester',
    'action_at' => date(DATETIME_FORMAT),
    'updated_at' => date(DATETIME_FORMAT)
], 'request_id = ?', [$requestId]);

// Notify all parties about cancellation
$cancellationMessage = 'A trip has been cancelled by the requester.';
$link = '/?page=requests&action=view&id=' . $requestId;

// Notify requester (already knows, but for consistency)
notify(
    $request->user_id,
    'request_cancelled',
    'Trip Cancelled',
    'You have cancelled your vehicle request.',
    $link
);

// Notify passengers
notifyPassengers(
    $requestId,
    'request_cancelled',
    'Trip Cancelled',
    'A trip you were part of has been cancelled by the requester.',
    $link
);

// Notify requested driver or assigned driver
$driverId = $request->driver_id ?: $request->requested_driver_id;
if ($driverId) {
    notifyDriver(
        $driverId,
        'trip_cancelled_driver',
        'Trip Cancelled',
        'A trip you were ' . ($request->driver_id ? 'assigned to drive' : 'requested to drive') . ' has been cancelled by the requester.',
        $link
    );
}

// Audit log
auditLog('request_cancelled', 'request', $requestId, ['status' => $oldStatus], ['status' => STATUS_CANCELLED]);

redirectWith('/?page=requests', 'success', 'Request cancelled successfully.');
