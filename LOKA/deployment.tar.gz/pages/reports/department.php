<?php
/**
 * LOKA - Department Usage Report  
 */

requireRole(ROLE_APPROVER);
redirect('/?page=reports');
