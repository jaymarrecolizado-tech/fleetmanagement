<?php
/**
 * LOKA - Vehicle Utilization Report
 */

requireRole(ROLE_APPROVER);
redirect('/?page=reports');
