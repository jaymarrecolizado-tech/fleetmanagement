# LOKA Fleet Management - Deployment Checklist

## Pre-Deployment

- [ ] All code tested locally
- [ ] Database backup created
- [ ] All sensitive data removed from code
- [ ] Configuration files prepared for production

## Hostinger Setup

### 1. Database
- [ ] Database created in hPanel
- [ ] Database user created
- [ ] User granted ALL privileges
- [ ] Database credentials saved securely
- [ ] `config/database.php` updated with production credentials

### 2. Files Upload
- [ ] All files uploaded via FTP/File Manager
- [ ] File permissions set correctly (755 for folders, 644 for files)
- [ ] `.htaccess` file uploaded and configured
- [ ] `logs/` directory created with write permissions (755)

### 3. Configuration
- [ ] `config/database.php` - Database credentials updated
- [ ] `config/constants.php` - APP_URL and SITE_URL updated
- [ ] `config/mail.php` - SMTP credentials verified
- [ ] `config/security.php` - Production settings enabled
- [ ] `.htaccess` - RewriteBase and paths updated

### 4. Email Queue Cron Job
- [ ] Cron job created in hPanel (Advanced > Cron Jobs)
- [ ] Cron job frequency set (every 2 minutes recommended)
- [ ] Cron job path verified and tested
- [ ] Cron job logs checked for errors

### 5. SSL/HTTPS
- [ ] SSL certificate installed and active
- [ ] HTTPS redirect configured (if needed)
- [ ] SITE_URL uses https://

### 6. Testing
- [ ] Application accessible via domain
- [ ] Login works correctly
- [ ] Database connection successful
- [ ] Email notifications working (test after cron runs)
- [ ] All features tested
- [ ] Error logs checked

### 7. Security
- [ ] Error reporting disabled in production
- [ ] Sensitive files protected (.htaccess)
- [ ] Database credentials secure
- [ ] SMTP credentials secure
- [ ] File permissions correct

### 8. Performance
- [ ] Email queue processing verified
- [ ] No blocking operations
- [ ] Cron job running smoothly

## Post-Deployment

- [ ] Monitor error logs for first 24 hours
- [ ] Verify emails are being sent
- [ ] Check cron job execution logs
- [ ] Test all critical workflows
- [ ] Backup database regularly

## Rollback Plan

If issues occur:
1. Restore database backup
2. Revert code changes
3. Check error logs
4. Verify configurations

## Support Contacts

- Hostinger Support: hPanel > Support
- Application Logs: `LOKA/logs/error.log`
- Cron Job Logs: hPanel > Cron Jobs > View Logs
