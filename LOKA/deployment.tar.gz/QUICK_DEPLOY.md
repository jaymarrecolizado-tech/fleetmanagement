# Quick Deployment Guide - Hostinger

## 🚀 Fast Setup (5 Steps)

### 1. Upload Files
Upload entire `LOKA` folder to `public_html/` via FTP or File Manager

### 2. Database Setup
- Create database in hPanel > Databases > MySQL Databases
- Import schema (if you have SQL file) via phpMyAdmin
- Update `config/database.php` with your credentials

### 3. Configure URLs
Edit `config/constants.php`:
```php
define('APP_URL', '');  // Empty if root, or '/subfolder' if in subfolder
define('SITE_URL', 'https://yourdomain.com');  // Your actual domain
```

### 4. Set Up Cron Job
hPanel > Advanced > Cron Jobs:
```
Frequency: */2 * * * *
Command: /usr/bin/php /home/u123456789/domains/yourdomain.com/public_html/LOKA/cron/process_queue.php
```
*(Update path to match your actual file location)*

### 5. Test
- Access: `https://yourdomain.com/LOKA` (or root if installed there)
- Login and test
- Create a request to test emails
- Wait 2 minutes for cron to process emails

## 📝 Configuration Files to Update

1. **`config/database.php`** - Database credentials
2. **`config/constants.php`** - APP_URL and SITE_URL
3. **`config/mail.php`** - Already configured (verify Gmail password)
4. **`.htaccess`** - Update RewriteBase if in subdirectory

## ✅ Verification Checklist

- [ ] App loads without errors
- [ ] Login works
- [ ] Database connection successful
- [ ] Cron job created and running
- [ ] Emails being sent (check after 2-5 minutes)
- [ ] HTTPS working (SSL enabled)

## 🔧 Common Issues

**500 Error:** Check file permissions (755 folders, 644 files)

**Database Error:** Verify credentials in `config/database.php`

**Emails Not Sending:** 
- Check cron job is running
- Verify cron job path is correct
- Check `email_queue` table in database

**Cron Not Working:**
- Verify PHP path: usually `/usr/bin/php`
- Check file path is absolute and correct
- View cron logs in hPanel

## 📚 Full Documentation

See `DEPLOYMENT_HOSTINGER.md` for detailed instructions.
