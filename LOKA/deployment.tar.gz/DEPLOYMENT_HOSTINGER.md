# LOKA Fleet Management - Hostinger Deployment Guide

## Pre-Deployment Checklist

- [ ] Database created in Hostinger hPanel
- [ ] Database user created with proper permissions
- [ ] Domain/subdomain configured
- [ ] SSL certificate enabled (HTTPS)
- [ ] PHP version 8.0+ enabled
- [ ] Gmail App Password ready for email

## Step 1: Upload Files

1. **Upload all files** to your Hostinger hosting:
   - Via FTP (FileZilla, WinSCP) or
   - Via Hostinger File Manager

2. **Recommended structure:**
   ```
   public_html/
   └── LOKA/
       ├── index.php
       ├── config/
       ├── classes/
       ├── pages/
       └── ...
   ```

   OR if installing in root:
   ```
   public_html/
       ├── index.php
       ├── config/
       ├── classes/
       └── ...
   ```

## Step 2: Database Setup

1. **Create Database in Hostinger hPanel:**
   - Go to **Databases** > **MySQL Databases**
   - Create new database (note the full name, e.g., `u123456789_fleet`)
   - Create new user (note the full username, e.g., `u123456789_admin`)
   - Grant ALL privileges to user on database

2. **Import Database Schema:**
   - Go to **phpMyAdmin** in hPanel
   - Select your database
   - Import the SQL file (if you have one) or run the SQL scripts from `LOKA/migrations/`

3. **Update Database Config:**
   - Edit `LOKA/config/database.php`
   - Update with your Hostinger database credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'u123456789_fleet');  // Your database name
   define('DB_USER', 'u123456789_admin');  // Your database user
   define('DB_PASS', 'your_password');     // Your database password
   ```

## Step 3: Configure URLs

1. **Edit `LOKA/config/constants.php`:**
   ```php
   // If installed in root:
   define('APP_URL', '');
   define('SITE_URL', 'https://yourdomain.com');
   
   // If installed in subdirectory (e.g., /fleet):
   define('APP_URL', '/fleet');
   define('SITE_URL', 'https://yourdomain.com/fleet');
   ```

2. **Update `.htaccess` if needed:**
   - If installed in subdirectory, ensure `.htaccess` paths are correct

## Step 4: Set Up Email Queue Cron Job

**Hostinger uses cPanel Cron Jobs:**

1. **Log into Hostinger hPanel**
2. **Go to:** Advanced > Cron Jobs
3. **Add New Cron Job:**
   - **Frequency:** Every 2 minutes: `*/2 * * * *`
   - **Command:** 
   ```bash
   /usr/bin/php /home/u123456789/domains/yourdomain.com/public_html/LOKA/cron/process_queue.php
   ```
   - **Note:** Update the path to match your actual file path
   - To find your path, check hPanel > File Manager > right-click on `process_queue.php` > Properties

4. **Alternative (if path doesn't work):**
   ```bash
   cd /home/u123456789/domains/yourdomain.com/public_html/LOKA && /usr/bin/php cron/process_queue.php
   ```

5. **Test the cron job:**
   - Create a test request that triggers an email
   - Wait 2 minutes
   - Check if email was sent
   - Check email_queue table in database for status

## Step 5: Configure Email (Gmail SMTP)

1. **Edit `LOKA/config/mail.php`:**
   - Already configured with Gmail
   - Ensure Gmail App Password is correct
   - Test by creating a request

2. **Gmail Setup (if needed):**
   - Go to Google Account > Security
   - Enable 2-Step Verification
   - Generate App Password
   - Use App Password in `mail.php`

## Step 6: File Permissions

Set proper permissions via File Manager or FTP:
- **Folders:** 755
- **Files:** 644
- **Writable folders (if any):** 775

## Step 7: Security Settings

1. **Edit `LOKA/config/security.php`:**
   - Set `APP_ENV` to `'production'` or ensure it detects production
   - Enable HTTPS in security settings

2. **Update `LOKA/index.php`:**
   - Ensure `IS_PRODUCTION` is true in production
   - Error reporting should be off in production

## Step 8: Test the Application

1. **Access the application:**
   - `https://yourdomain.com/LOKA` (if in subdirectory)
   - `https://yourdomain.com` (if in root)

2. **Test login:**
   - Use admin credentials
   - Verify session works

3. **Test email notifications:**
   - Create a request
   - Wait for cron job to process (2 minutes)
   - Check if emails are sent

4. **Check error logs:**
   - Hostinger hPanel > Advanced > Error Log
   - Or check `LOKA/logs/error.log` if configured

## Step 9: Performance Optimization

1. **Enable PHP OPcache** (usually enabled by default on Hostinger)
2. **Enable Gzip compression** (usually enabled by default)
3. **Monitor email queue:**
   - Check `email_queue` table regularly
   - Ensure cron job is running

## Troubleshooting

### Emails Not Sending
- Check cron job is running (hPanel > Cron Jobs > View Logs)
- Check email_queue table status
- Verify SMTP credentials
- Check Hostinger error logs

### Database Connection Error
- Verify database credentials
- Check database user has proper permissions
- Ensure database exists

### 500 Internal Server Error
- Check file permissions
- Check `.htaccess` syntax
- Check PHP error logs
- Verify PHP version (8.0+)

### Cron Job Not Working
- Verify cron job path is correct
- Check cron job logs in hPanel
- Test manually: SSH into server and run the command
- Ensure PHP path is correct (`/usr/bin/php` or check with `which php`)

## Support

For issues:
1. Check Hostinger error logs
2. Check application error logs
3. Verify all configurations
4. Test cron job manually

## Important Notes

- **Never commit** `database.php` with real credentials to Git
- **Always use HTTPS** in production
- **Backup database** regularly
- **Monitor email queue** to ensure emails are being processed
- **Test thoroughly** before going live
