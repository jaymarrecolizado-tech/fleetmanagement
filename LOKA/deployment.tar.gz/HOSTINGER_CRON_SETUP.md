# Hostinger Cron Job Setup for Email Queue

## Quick Setup

1. **Login to Hostinger hPanel**
2. **Navigate to:** Advanced > Cron Jobs
3. **Add New Cron Job** with these settings:

### Option 1: Every 2 Minutes (Recommended)
```
Frequency: */2 * * * *
Command: /usr/bin/php /home/u123456789/domains/yourdomain.com/public_html/LOKA/cron/process_queue.php
```

### Option 2: Every 5 Minutes (Less frequent)
```
Frequency: */5 * * * *
Command: /usr/bin/php /home/u123456789/domains/yourdomain.com/public_html/LOKA/cron/process_queue.php
```

## Finding Your Correct Path

1. **Method 1: File Manager**
   - Go to File Manager in hPanel
   - Navigate to `public_html/LOKA/cron/process_queue.php`
   - Right-click > Properties
   - Copy the full path

2. **Method 2: SSH (if available)**
   ```bash
   pwd
   # This shows your current directory
   ```

3. **Method 3: Create a test file**
   - Create `test_path.php` in LOKA folder:
   ```php
   <?php
   echo __DIR__;
   ```
   - Access via browser to see the path

## Alternative Command Format

If the direct path doesn't work, use:
```bash
cd /home/u123456789/domains/yourdomain.com/public_html/LOKA && /usr/bin/php cron/process_queue.php
```

## Testing the Cron Job

1. **Manual Test via SSH:**
   ```bash
   /usr/bin/php /full/path/to/LOKA/cron/process_queue.php
   ```

2. **Check Cron Job Logs:**
   - In hPanel > Cron Jobs
   - View execution logs
   - Check for errors

3. **Test Email Flow:**
   - Create a request in the app
   - Wait 2-5 minutes (depending on cron frequency)
   - Check if email was received
   - Check `email_queue` table in database

## Common Issues

### Issue: Cron job not executing
**Solution:**
- Verify PHP path: `which php` (via SSH)
- Check file permissions (should be 644)
- Verify file path is correct

### Issue: Permission denied
**Solution:**
- Ensure file is readable: `chmod 644 process_queue.php`
- Check directory permissions: `chmod 755 cron/`

### Issue: Emails still not sending
**Solution:**
- Check cron job logs for errors
- Verify SMTP credentials in `config/mail.php`
- Check database connection
- Verify `email_queue` table exists

## Monitoring

Check email queue status:
- Via database: `SELECT status, COUNT(*) FROM email_queue GROUP BY status;`
- Via admin panel (if available): Settings > Email Queue

## Frequency Recommendations

- **High traffic:** Every 1-2 minutes
- **Medium traffic:** Every 5 minutes
- **Low traffic:** Every 10 minutes

Note: Hostinger may have limits on cron job frequency. Check their documentation.
