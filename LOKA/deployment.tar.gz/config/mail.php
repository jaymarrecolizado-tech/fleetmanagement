<?php
/**
 * LOKA - Mail Configuration
 */

// SMTP Settings - Gmail
define('MAIL_ENABLED', true);
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', 'jelite.demo@gmail.com');
define('MAIL_PASSWORD', 'typq agna gfvg mlbt');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'jelite.demo@gmail.com');
define('MAIL_FROM_NAME', 'LOKA Fleet Management');

// Email Templates
define('MAIL_TEMPLATES', [
    // Approver notifications
    'request_submitted' => [
        'subject' => 'New Vehicle Request Submitted',
        'template' => 'A new vehicle request has been submitted and requires your approval.'
    ],
    'request_pending_motorpool' => [
        'subject' => 'Request Awaiting Vehicle Assignment',
        'template' => 'A request has been approved by department and needs vehicle/driver assignment.'
    ],
    
    // Requester notifications
    'request_confirmation' => [
        'subject' => 'Your Vehicle Request Has Been Submitted',
        'template' => 'Your vehicle request has been submitted successfully and is now awaiting approval.'
    ],
    'request_approved' => [
        'subject' => 'Your Request Has Been Approved',
        'template' => 'Great news! Your vehicle request has been approved.'
    ],
    'request_rejected' => [
        'subject' => 'Your Request Has Been Rejected',
        'template' => 'Unfortunately, your vehicle request has been rejected.'
    ],
    'vehicle_assigned' => [
        'subject' => 'Vehicle and Driver Assigned',
        'template' => 'A vehicle and driver have been assigned to your request.'
    ],
    'trip_completed' => [
        'subject' => 'Trip Completed',
        'template' => 'Your trip has been marked as completed.'
    ],
    
    // Passenger notifications
    'added_to_request' => [
        'subject' => 'You Have Been Added to a Vehicle Request',
        'template' => 'You have been added as a passenger to a vehicle request.'
    ],
    'removed_from_request' => [
        'subject' => 'Removed from Vehicle Request',
        'template' => 'You have been removed from a vehicle request.'
    ],
    'request_modified' => [
        'subject' => 'Trip Details Updated',
        'template' => 'A trip you are part of has been modified.'
    ],
    'request_cancelled' => [
        'subject' => 'Trip Cancelled',
        'template' => 'A trip you were part of has been cancelled.'
    ],
    
    // Driver notifications
    'driver_requested' => [
        'subject' => 'You Have Been Requested as Driver',
        'template' => 'You have been requested as the driver for a vehicle request. The request is pending approval.'
    ],
    'driver_assigned' => [
        'subject' => 'You Have Been Assigned as Driver',
        'template' => 'You have been assigned as the driver for an approved vehicle request.'
    ],
    'driver_status_update' => [
        'subject' => 'Trip Status Update',
        'template' => 'There has been an update to a trip you are assigned to drive.'
    ],
    'trip_cancelled_driver' => [
        'subject' => 'Trip Cancelled - Driver Assignment',
        'template' => 'A trip you were assigned to drive has been cancelled.'
    ],
    
    // Default template for notifications without specific template
    'default' => [
        'subject' => 'Fleet Management Notification',
        'template' => 'You have received a notification from the Fleet Management System.'
    ]
]);
